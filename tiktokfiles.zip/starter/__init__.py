"""Participant starter package."""

